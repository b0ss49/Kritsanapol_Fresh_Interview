package com.example.phasuwut.project_android_3;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private SectionsPageAdapter mSectionsPageAdapter;
    private ViewPager mViewPager;
    final Activity activity =this;

    TabLayout tabLayout;
    DatabaseHandler mydb;//DB
    String cur_ISBN;
    ArrayList<String> finalList;
    int[] totalcount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        finalList = new ArrayList<String>();
        mSectionsPageAdapter = new SectionsPageAdapter(getSupportFragmentManager());
        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);
        tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        mydb = new DatabaseHandler(this);
        totalcount = new int[500];
        for(int i=0;i<500;i++){totalcount[i]=0;}
    }



    private void setupViewPager(ViewPager viewPager) {
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new Database_Management(), "Database Management");
        adapter.addFragment(new Raed_data_all(), "ดูข้อมูลทั้งหมด");
        adapter.addFragment(new selling_Activity(), "การขาย");

        viewPager.setAdapter(adapter);
    }



// สแกนบาร์โค้ด
    public void onClickk(View view) {

        IntentIntegrator intentIntegrator = new IntentIntegrator(activity);
        intentIntegrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);// เปลื่ยนให้อ่านบาร์โค้ด ตรงนี้่
        intentIntegrator.setPrompt("Scan");
        intentIntegrator.setCameraId(0);
        intentIntegrator.setBeepEnabled(false);
        intentIntegrator.setBarcodeImageEnabled(false);
        intentIntegrator.initiateScan();
    }


    public void read_data(View view)
    {
        ListView lv = (ListView) findViewById(R.id.list_view1);
        ArrayList<String> str = mydb.getAllTodoList();
        ArrayList<String> displayString = new ArrayList<String>();

        for (int i=0;i<str.size();i++)
        {
            String[] g = str.get(i).split(",");
            g[0] = g[0].substring(1);
            Log.i("GGGGG",g[0]);
            String data = "Index:"+g[0]+" ISBN:"+g[1]+" Book Name:"+g[2]+" book_author:"+g[3]
                    +" Price:"+g[4]+" Count:"+g[5];
            displayString.add(data);
        }
        lv.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,displayString));


    }
    // สแกนบาร์โค้ด
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult re =IntentIntegrator.parseActivityResult(requestCode,resultCode,data);

        if(re !=null){
            if(re.getContents()==null){
                Toast.makeText(this,"ไม่ออก",Toast.LENGTH_SHORT).show();
            }
            else{
              //  t3.setText(re.getContents().toString());
               Toast.makeText(this,re.getContents(),Toast.LENGTH_SHORT).show();
                //  เครีย ค่าในหน้าจอทั้งหมด

                Log.i("kuy", "มึงจะบัคทำควยอะไร");
                cur_ISBN = re.getContents().toString();
               EditText EditText_ISBN;
             Log.i("kuy", "สัตว์");
                //EeditText_ISBN1.setText(re.getContents().toString());
                int i = tabLayout.getSelectedTabPosition();
               Log.i("kuy", String.valueOf(tabLayout.getSelectedTabPosition())+" "+cur_ISBN);
                EditText_ISBN = (EditText)findViewById(R.id.editText_ISBN);

                if(i==0)
                {
                    d_all();
                    EditText_ISBN.setText(cur_ISBN);
                    getE_TodoList();
                }
               if(i==2)
               {
                   EditText_ISBN = (EditText) findViewById(R.id.selling_isbn);
                   EditText_ISBN.setText(cur_ISBN);
                   getE_SellList(cur_ISBN);
               }

                //editText_ISBN_selling
                // // โชว์ข้อมูลในทั้งหม ในกรณีเรานั้นสแกนบอร์โค้ด
            }
        }
        else{
            super.onActivityResult(requestCode, resultCode, data);
        }


    }

    ArrayAdapter<String> sell_listAdapter;
    public void getE_SellList(String e){

        ListView lv1 = (ListView) findViewById(R.id.sell_view);
        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.i("Boss","OCLick");
                removeSelectedListItem(position);
            }
        });
        sell_listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,finalList);
        //lv1.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,finalList));
        String getEdit1 = e;
        int t = mydb.getAllTodoList().indexOf(mydb.getE_TodoList(e).get(0));
        EditText EditText1=(EditText)findViewById(R.id.selling_isbn);
        //getEdit1=EditText1.getText().toString();
        //sell_listAdapter.addAll(mydb.getE_TodoList(getEdit1));
        //sell_listAdapter.notifyDataSetChanged();
        //ListAdapter la = lv1.getAdapter();
        //lv1.setAdapter(sell_listAdapter);
        ArrayList<String> temp = mydb.getE_TodoList(EditText1.getText().toString());
        ArrayList<String> displayString = new ArrayList<String>();
        String[] g = temp.get(0).split(",");
        g[0] = g[0].substring(1);
        if(Integer.parseInt(g[5].substring(1))<(totalcount[t]+1))
        {
            Toast.makeText(activity, "จำนวนหนังสือไม่พอ", Toast.LENGTH_SHORT).show();
        }
        else {
            String data = "ISBN:"+g[1]+" Book Name:"+g[2]+" book_author:"+g[3]
                    +" Price:"+g[4];
            displayString.add(data);
            finalList.addAll(temp);
            sell_listAdapter.notifyDataSetChanged();
            lv1.setAdapter(sell_listAdapter);
            totalcount[t]++;
        }
    }

    public void removeSelectedListItem(int position)
    {
        int t = mydb.getAllTodoList().indexOf(finalList.get(position));
        Log.i("Boss","BeginRemoveSelectedPosition:"+position+" "+t);
        finalList.remove(position);
        totalcount[t]--;
        Log.i("Boss","Finish");
        sell_listAdapter.notifyDataSetChanged();
        ListView lv = (ListView) findViewById(R.id.sell_view);
        lv.setAdapter(sell_listAdapter);
    }








public void  process(View v){
    RadioButton myOption1 = (RadioButton) findViewById(R.id.radioButton_search); //ปุ่มต่างๆ
    RadioButton myOption2 = (RadioButton) findViewById(R.id.radioButton_delete);
    RadioButton myOption3 = (RadioButton) findViewById(R.id.radioButton_add);
    RadioButton  myOption4 = (RadioButton) findViewById(R.id.radioButton_modify);
    Log.i("ku", "ไอสัตว์ ควยยย");

    boolean kuy;
    if ((String.valueOf(myOption1.isChecked())) == "true") {
        kuy = myOption1.isChecked();
        String str0 = String.valueOf(kuy);
        //Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();
        getE_TodoList();
        Log.i("ku", "ค้นหา ");
    } else if ((String.valueOf(myOption2.isChecked())) == "true") {
        kuy = myOption2.isChecked();
        String str0 = String.valueOf(kuy);
        //Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();

        delete();
        Log.i("ku", "ลบ ");

    } else if ((String.valueOf(myOption3.isChecked())) == "true") {
        kuy = myOption3.isChecked();
        String str0 = String.valueOf(kuy);
        //Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();
        //Log.i("ku", "เพิ่ม นะ ");

        Eadd_data();


    } else if ((String.valueOf(myOption4.isChecked())) == "true") {
        kuy = myOption4.isChecked();
        String str0 = String.valueOf(kuy);

        update();

        Log.i("ku", "แก้ไข ");

    }
}

    public void Elength(){

        int kh;
        kh=mydb.getRecordCount();
        String ku=Integer.toString(kh);

        Log.i("ku","มีทั้งหมด " +ku);
    }

    public void Eadd_data(){

        EditText EditText1,EditText2,EditText3,EditText4,EditText5,EditText6;
        EditText1=(EditText)findViewById(R.id.editText_ISBN);
        EditText2=(EditText)findViewById(R.id.editText_book);
        EditText3=(EditText)findViewById(R.id.editText_author_book);
        EditText4=(EditText)findViewById(R.id.editText_price);
        EditText5=(EditText)findViewById(R.id.editText_number);
       // EditText6=(EditText)findViewById(R.id.editText6);
        Log.i("ku", "อีดอก เพิ่ม");

        String getEdit1,getEdit2,getEdit3,getEdit4,getEdit5,getEdit6;
        getEdit1=EditText1.getText().toString();
        getEdit2=EditText2.getText().toString();
        getEdit3=EditText3.getText().toString();
        getEdit4=EditText4.getText().toString();
        getEdit5=EditText5.getText().toString();


        int g4;
        int g5;
        int gx;
        try {
            g4=Integer.parseInt(getEdit4);
            //System.out.println("int");
            g5=Integer.parseInt(getEdit5);
            gx=g4*g5;
            getEdit6= Integer.toString(gx);

            //Elength();
            if(getEdit1==null||getEdit2==null||getEdit3==null||getEdit4==null||getEdit5==null){
                Toast.makeText(this,"ใส่ข้อมูลให้ครบ",Toast.LENGTH_SHORT).show();
                Log.i("ku", "ควย");

            }
            else {
                if(check(getEdit1)==1){
                    Log.i("ku", "ไอสัตว์มีข้อมูลแล้ว");
                    int a=mydb.updateContact(getEdit1,getEdit2,getEdit3,getEdit4,getEdit5,getEdit6);
                    Log.i("ku", "กูอัปแดด ข้อมูลให้แทน นะ");
                    Log.i("ku", "เพิ่มแล้วนะ ");
                    Toast.makeText(this,"ข้อมูลถูกอัปแดด แล้วนะ",Toast.LENGTH_SHORT).show();
                    d_all();
                    Elength();
                }
                else {
                    long result;
                    result = mydb.addRecord(getEdit1,getEdit2,getEdit3,getEdit4,getEdit5,getEdit6);//เพิ่มข้อมูลลงคาราง
                    Log.i("ku", " กูเพิ่ม ข้อมูลแล้ว");
                    Toast.makeText(this,"ข้อมูลถูกเพิ่มแล้วนะ",Toast.LENGTH_SHORT).show();
                    Elength();
                    d_all();
                    //Log.i("ku", "เพิ่มแล้วนะ ");

                }

            }




        } catch (Exception e) {
            Toast.makeText(this,"ใส่ข้อมูลไม่ถูกต้อง",Toast.LENGTH_SHORT).show();
            Log.i("ku", "อีดอก type ");
            Elength();
        }



       // int g4=Integer.parseInt(getEdit4);
        //int g5=Integer.parseInt(getEdit5);




       // Toast.makeText(this,re.getContents(),Toast.LENGTH_LONG).show();
       // Log.i("ku", "ไอสัตว์ออกยัง");






    }
    public int check(String t1){
        ArrayList<String> todoList = new ArrayList<String>();
        todoList=mydb.getE_TodoList(t1);
        String kuo="[]";
        if(todoList.toString()=="[]"){
            Log.i("ku", " ไม่ซ้ำ");

            return 0;
        }
        else{
            Log.i("ku", " ซ้ำ มีข้อมูลแล้ว");
            return 1;
        }
        //Log.i("my", todoList.toString());
    }



    public void getE_TodoList(){


        String getEdit1;
        EditText EditText1=(EditText)findViewById(R.id.editText_ISBN);
        getEdit1=EditText1.getText().toString();

        int a11=check(getEdit1);
        if(a11==1){
            ArrayList<String> todoList = new ArrayList<String>();
            todoList=mydb.getE_TodoList(getEdit1);
            Log.i("my", todoList.toString());

            EditText EditText2,EditText3,EditText4,EditText5,EditText6;
            //EditText1=(EditText)findViewById(R.id.editText_ISBN);
            EditText2=(EditText)findViewById(R.id.editText_book);
            EditText3=(EditText)findViewById(R.id.editText_author_book);
            EditText4=(EditText)findViewById(R.id.editText_price);
            EditText5=(EditText)findViewById(R.id.editText_number);

            EditText1.setText(mydb.z1);
            EditText2.setText(mydb.z2);
            EditText3.setText(mydb.z3);
            EditText4.setText(mydb.z4);
            EditText5.setText(mydb.z5);


        }
        else{
            Toast.makeText(this,"ไม่พบข้อมูล",Toast.LENGTH_SHORT).show();

        }



    }

    public void updateCount(String data,int mode,int value)
    {
        Log.i("Boss","HDhkjhj");
        if(check(data)==1){//มีข้อมูล
            try {
                Cursor cur = mydb.getE_Cursor(data);
                cur.moveToFirst();
                //Log.i("Boss",cur.getString(0));
                mydb.updateContact(cur.getString(1), cur.getString(2),cur.getString(3) , cur.getString(5),String.valueOf(Integer.valueOf(cur.getString(5))-1),cur.getString(6));
                Log.i("Boss","Update Success");
            }
            catch (Exception e) {
                Toast.makeText(this,"ใส่ข้อมูลไม่ถูกต้อง",Toast.LENGTH_SHORT).show();
                Log.i("ku", "อีดอก type "+e.getMessage());
                // Elength();
            }
        }
        else{
            Toast.makeText(this,"ไม่พบข้อมูล",Toast.LENGTH_SHORT).show();
            Log.i("Boss","No Data");
        }
    }


    public void update(){
        String getEdit1,getEdit2,getEdit3,getEdit4,getEdit5,getEdit6;

        EditText EditText1,EditText2,EditText3,EditText4,EditText5,EditText6;
        EditText1=(EditText)findViewById(R.id.editText_ISBN);
        EditText2=(EditText)findViewById(R.id.editText_book);
        EditText3=(EditText)findViewById(R.id.editText_author_book);
        EditText4=(EditText)findViewById(R.id.editText_price);
        EditText5=(EditText)findViewById(R.id.editText_number);

        getEdit1=EditText1.getText().toString();
        getEdit2=EditText2.getText().toString();
        getEdit3=EditText3.getText().toString();
        getEdit4=EditText4.getText().toString();
        getEdit5=EditText5.getText().toString();


        if(check(getEdit1)==1){//มีข้อมูล
            try {
                int g4;
                int g5;
                 int gx;
                 g4 = Integer.parseInt(getEdit4);
                //System.out.println("int");
                g5 = Integer.parseInt(getEdit5);
                 gx = g4 * g5;
                getEdit6 = Integer.toString(gx);
                int a=mydb.updateContact(getEdit1,getEdit2,getEdit3,getEdit4,getEdit5,getEdit6);
             Log.i("my", "อับแดด แล้วนะ ");
                Toast.makeText(this,"อับแดด แล้วนะ",Toast.LENGTH_SHORT).show();

                d_all();
            }
         catch (Exception e) {
            Toast.makeText(this,"ใส่ข้อมูลไม่ถูกต้อง",Toast.LENGTH_SHORT).show();
            // Log.i("ku", "อีดอก type ");
         // Elength();
        }
    }
    else{
        Toast.makeText(this,"ไม่พบข้อมูล",Toast.LENGTH_SHORT).show();
        }
    }


    public  void  d_all(){//ล้างค่าบนหน้าจอ
        EditText EditText1,EditText2,EditText3,EditText4,EditText5,EditText6;
        EditText1=(EditText)findViewById(R.id.editText_ISBN);
        EditText2=(EditText)findViewById(R.id.editText_book);
        EditText3=(EditText)findViewById(R.id.editText_author_book);
        EditText4=(EditText)findViewById(R.id.editText_price);
        EditText5=(EditText)findViewById(R.id.editText_number);
        EditText1.setText("");
        EditText2.setText("");
        EditText3.setText("");
        EditText4.setText("");
        EditText5.setText("");
    }


    public void delete(){
        EditText EditText1;
        EditText1=(EditText)findViewById(R.id.editText_ISBN);
        String getEdit1;
        getEdit1=EditText1.getText().toString();

        int a1;
       a1= check(getEdit1);

       if(a1==1){
           mydb.deleteRecord(getEdit1);
           Toast.makeText(this,"ลบข้อมูลให้ แล้วนะ",Toast.LENGTH_SHORT).show();
           Log.i("my", "ลบข้อมูลให้ แล้วนะ");
           d_all();

       }
       else{
           Toast.makeText(this,"เราไม่พบข้อมูล กรุณาใสข้อมูลใหม่ ",Toast.LENGTH_SHORT).show();
           Log.i("my", "ไอสัตว์ไม่เจอ");
       }


        //ArrayList<String> todoList = new ArrayList<String>();
        //todoList=mydb.getE_TodoList("n1");


    }
    public void Refresh(View v)
    {
        ListView lv1 = (ListView) findViewById(R.id.sell_view);
        lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.i("Boss","OCLick");
                removeSelectedListItem(position);
            }
        });
        sell_listAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,finalList);
        lv1.setAdapter(sell_listAdapter);
    }

    public void addSelectedISBN_Sell(View view)
    {
        try {
            ListView lv1 = (ListView) findViewById(R.id.sell_view);
            lv1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //Log.i("Boss","OCLick");
                    removeSelectedListItem(position);
                }
            });
            sell_listAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, finalList);
            EditText isbn_sell = (EditText) findViewById(R.id.selling_isbn);
            int t = mydb.getAllTodoList().indexOf(mydb.getE_TodoList(isbn_sell.getText().toString()).get(0));
            ArrayList<String> temp = mydb.getE_TodoList(isbn_sell.getText().toString());
            ArrayList<String> displayString = new ArrayList<String>();
            String[] g = temp.get(0).split(",");
            g[0] = g[0].substring(1);
            if (Integer.parseInt(g[5].substring(1)) < (totalcount[t] + 1)) {
                Toast.makeText(activity, "จำนวนหนังสือไม่พอ", Toast.LENGTH_SHORT).show();
            } else {
                String data = "ISBN:" + g[1] + " Book Name:" + g[2] + " book_author:" + g[3]
                        + " Price:" + g[4];
                displayString.add(data);
                finalList.addAll(temp);
                sell_listAdapter.notifyDataSetChanged();
                lv1.setAdapter(sell_listAdapter);
                totalcount[t]++;
            }
        }catch (Exception e){
            Toast.makeText(activity, "กรุณาป้อนข้อมูลครับ ...", Toast.LENGTH_SHORT).show();
        }
            //Log.i("GGGGG",g[0]);
        
    }
    public void onSellClick(View view)
    {
        int t;
        int total = 0;
        for(int i=0;i<finalList.size();i++)
        {

            String[] temp = finalList.get(i).split(",");
            Log.i("Sell","Sell"+temp[4]);
            total+= Integer.parseInt(temp[4].substring(1));

        }

        AlertDialog.Builder builder =
                new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("ราคารวมคือ "+total+" ท่านต้องการเช็คเอาท์เลยหรือไม่");
        builder.setPositiveButton("ใช่", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                try {
                    ArrayList<String> temp2 = new ArrayList<String>();
                    for (int i = 0; i < finalList.size(); i++) {
                        String isbn_temp = (finalList.get(i).split(","))[1].substring(1);
                        if (temp2.contains(isbn_temp)) {
                            Log.i("Boss", "Update" + isbn_temp);
                        } else {
                            temp2.add(isbn_temp);
                            Log.i("Boss", "Update2" + isbn_temp);
                        }

                        updateCount(isbn_temp, 0, 1);
                    }
                    for(int i=0;i<500;i++){totalcount[i]=0;}
                    finalList.clear();
                    sell_listAdapter.notifyDataSetChanged();
                    ((ListView)findViewById(R.id.sell_view)).setAdapter(sell_listAdapter);
                    Toast.makeText(getApplicationContext(),
                            "ขอบคุณที่ใช้บริการ", Toast.LENGTH_LONG).show();
                }catch (Exception e){
                    Toast.makeText(activity, "คุณไม่ได้เพิ่มหนังสือลงตะกร้า", Toast.LENGTH_SHORT).show();
                }

                
            }
        });
        builder.setNegativeButton("ไม่ใช่", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //dialog.dismiss();
            }
        });
        builder.show();
    }

}
