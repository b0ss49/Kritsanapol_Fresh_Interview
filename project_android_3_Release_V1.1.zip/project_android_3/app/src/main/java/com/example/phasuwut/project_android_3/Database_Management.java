package com.example.phasuwut.project_android_3;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class Database_Management extends Fragment {

    RadioButton myOption1, myOption2, myOption3, myOption4;
    Button  Ebutton_scan_code;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.database_management_activity, container, false);

        myOption1 = (RadioButton) view.findViewById(R.id.radioButton_search); //ปุ่มต่างๆ
        myOption2 = (RadioButton) view.findViewById(R.id.radioButton_delete);
        myOption3 = (RadioButton) view.findViewById(R.id.radioButton_add);
        myOption4 = (RadioButton) view.findViewById(R.id.radioButton_modify);

/*
        Ebutton_scan_code = (Button) view.findViewById(R.id.button_process);
        Ebutton_scan_code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean kuy;
                kuy = myOption1.isChecked();
                String str = String.valueOf(kuy);


                if ((String.valueOf(myOption1.isChecked())) == "true") {
                    kuy = myOption1.isChecked();
                    String str0 = String.valueOf(kuy);
                   // Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();
                    Log.i("ku", "ค้นหา ");
                } else if ((String.valueOf(myOption2.isChecked())) == "true") {
                    kuy = myOption2.isChecked();
                    String str0 = String.valueOf(kuy);
                   // Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();
                    Log.i("ku", "ลบ ");

                } else if ((String.valueOf(myOption3.isChecked())) == "true") {
                    kuy = myOption3.isChecked();
                    String str0 = String.valueOf(kuy);
                    //Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();
                    Log.i("ku", "เพิ่ม ");

                } else if ((String.valueOf(myOption4.isChecked())) == "true") {
                    kuy = myOption4.isChecked();
                    String str0 = String.valueOf(kuy);
                   // Toast.makeText(getActivity(), str0, Toast.LENGTH_SHORT).show();
                    Log.i("ku", "แก้ไข ");

                }

            }
        });
        */


        return view;
    }
}